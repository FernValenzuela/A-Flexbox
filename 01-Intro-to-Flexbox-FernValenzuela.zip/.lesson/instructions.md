# Instructions  

---

Get started with the magic of flexbox! This is a short, simple lesson
with two parts. In part one, you will turn three divs into equally spaced
columns using flexbox. In part two, you will create your own flexbox
from scratch using HTML and CSS. The flex items should be labeled (have 
text content of) `ONE`, `TWO`, `THREE`, `FOUR`, and `FIVE`.